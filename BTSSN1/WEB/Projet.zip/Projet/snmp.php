<?php

$ip=$_GET["ip"];

$PColorB = snmp2_get($ip, "public", "1.3.6.1.2.1.43.11.1.1.9.1.1"); //renvoie le niveau de noir
$PColorC = snmp2_get($ip, "public", "1.3.6.1.2.1.43.11.1.1.9.1.2"); //renvoie le niveau de Cyan
$PColorM = snmp2_get($ip, "public", "1.3.6.1.2.1.43.11.1.1.9.1.3"); //renvoie le niveau de Magenta
$PColorJ = snmp2_get($ip, "public", "1.3.6.1.2.1.43.11.1.1.9.1.4"); //renvoie le niveau de Jaune

$PName = explode(" ",snmp2_get($ip, "public", "1.3.6.1.2.1.1.5.0"))[1]; //Name
$PModel = explode(": ",snmp2_get($ip, "public", "1.3.6.1.2.1.25.3.2.1.3.1"))[1];//Model
$PSerialNum = explode("\"",snmp2_get($ip, "public", "1.3.6.1.2.1.43.5.1.1.17.1"))[1];//Serial number

for ($i=0;$i<sizeof(snmp2_walk($ip, "public", "1.3.6.1.2.1.43.18.1.1.7"));$i++)
{
    $PErrCode = explode(": ",snmp2_walk($ip, "public", "1.3.6.1.2.1.43.18.1.1.7")[$i])[1];//Code d'erreur
}
for ($i=0;$i<sizeof(snmp2_walk($ip, "public", "1.3.6.1.2.1.43.18.1.1.8"));$i++)
{
    $PErrDesc = hex2str(preg_replace("/\s+/","",explode(": ",snmp2_walk($ip, "public", "1.3.6.1.2.1.43.18.1.1.8")[$i])[1]));//Description des erreurs
}

$Pstatus = explode(" ",snmp2_walk($ip, "public", "1.3.6.1.2.1.25.3.5.1.1")[0])[1];//printer status (printing, idle etc...)

$PColorB = intval(preg_replace('/[^0-9]/', '', $PColorB));
$PColorC = intval(preg_replace('/[^0-9]/', '', $PColorC));
$PColorM = intval(preg_replace('/[^0-9]/', '', $PColorM));
$PColorJ = intval(preg_replace('/[^0-9]/', '', $PColorJ));

if(($PColorB > 100)||($PColorB > 100)||($PColorB > 100)||($PColorB > 100)){
    $PColorB = ($PColorB*100)/22000;
    $PColorC = ($PColorC*100)/15000;
    $PColorM = ($PColorM*100)/15000;
    $PColorJ = ($PColorJ*100)/15000;
}

// Avec les imprimante Xerox il faut faire un calcul pour obtenir le pourcentage car de base c'est une estimation de page
// nbr_restanteDePage * 100 / nbr_maxDePage(22000 pour le Noir /15000 Cyan /15000 Magenta/15000 Jaune)

$PrtStatus = array(
    "InkLevel" => array(
        "Black" => $PColorB,
        "Cyan" => $PColorC,
        "Magenta" => $PColorM,
        "Yellow" => $PColorJ,
    ),
    "PrtError" => array(
        "ErrorCode" => $PErrCode,
        "ErrocDesc" => $PErrDesc,
    ),
    "PrtInfo" => array(
        "Ip" => "$ip",
        "Name" => "$PName",
        "Model" => "$PModel",
        "SerialNumb" => "$PSerialNum",
    )
    
);

echo json_encode($PrtStatus);


//Fonction convertion d'Hexa à String
function hex2str($hex) {
    $str = '';
    for($i=0;$i<strlen($hex);$i+=2) $str .= chr(hexdec(substr($hex,$i,2)));
    return $str;
}