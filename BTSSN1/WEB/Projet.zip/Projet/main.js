window.onload = timer()//Premiére éxécution de la fonction "timer()" au chargement de la page
function timer ()
{
    for(let i=0;i<$(".ip").length;i++)
    {
        var ip = $(".ip")[i].innerText;
        var name =$(".prt-name")[i].innerText;//L'ip = au contenu TEXT de la classe ".ip"
        var started = new Date().getTime();//On recupére l'attribut Time de l'objet "Date"

        $.ajax({ type: "GET",//requête AJAX avec JQUERRY on demande une entête
                url: "https://"+ip+"/hp/device/InternalPages/Index?id=SuppliesStatus",//On lui passe la cible 
                cache:false,//On empêche le navigateur de généré du cache car ça casserais le système
                complete: function(output)//Fonction a éxécuté aprés l'envoie
                { 

                    var ended = new Date().getTime();//On recupére l'attribut Time de l'objet "Date"
                    var milliseconds = ended - started;//Temp de réponse = le temps à la réception - le temps a l'envoi

                    if (milliseconds > 4000) //Si le délai = 2s imprimante éteinte 
                    {
                        console.log("Délai dépassé");//Indication délai dépasé console
                        document.getElementsByClassName("im")[i].src="img/greyPrint.png"//Met l'image imprimente en gris
                    }
                    else//Sinon imprimente allumé
                    {
                        console.log("Le ping de " + name +  " est de : "+milliseconds+" ms");//Affiche le ping dans la console
                        document.getElementsByClassName("im")[i].src="img/greenPrint.png"//Met l'image imprimente en vert 
                    }

                    
                }
            });
    }
    for(let i=0;i<$(".ip").length;i++)
    {
        $.ajax({
            type: "GET",
            url: "snmp.php",
            data:"ip="+$(".ip")[i].innerText,
            dataType: "json",
            complete: function(rsp)
            {
                console.log(rsp);
            }
        });
    }
}; 

//var loop=setInterval("timer()", 60000*5);//éxécution de la fonction "timer()" toute les: 60000*5 = 5mins