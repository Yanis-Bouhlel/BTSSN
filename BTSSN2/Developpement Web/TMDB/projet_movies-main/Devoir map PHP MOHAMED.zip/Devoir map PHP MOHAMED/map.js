// when page is ready, initialize the map!

function setInfoMarker(place, marker) {

    // variables pour affichage du html
    var namePlace = place["namePlace"];
    var commentaire = place["commentaire"];
    var url_photo = place["photo"];

    const contentString =
        '<div id="content">' +
        '<div id="siteNotice">' +
        '</div>' +
        '<h1 id="firstHeading" class="firstHeading">' + namePlace + '</h1>' +
        '<div id="bodyContent">' +
        '<p>' + commentaire + '</p>' +
        '<img src="' + url_photo + '" width=300em heigth=300em> ' +
        '</div>' +
        '<br/>' +
        '</div>';

    const infowindow = new google.maps.InfoWindow({
        content: contentString,
    });

    marker.addListener("mouseover", () => {
        infowindow.open(this.map, marker);
    });

    marker.addListener("mouseout", () => {
        infowindow.close(this.map, marker);
    })

}


/**
 * @param : name (nom de la personne dans le fichier json dataPersonnality)
 * called by evt onchange from select in  map.php
 * @return : met à jour la map avec les  infos json de la personne avec le name
 */
function mapPersonnality(email) {
    console.log(email);

    $.ajax({
        url: "getPersonne.php",
        method: "GET",
        data: { emailPersonne: email },
        dataType: "json",
        success: function (personne) {
            //personne = JSON.parse(personne);
            console.log(personne.markers);
            places = personne.markers;

            var options = {
                center: new google.maps.LatLng(10, 10),
                zoom: 3,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            };

            // Create Map
            const map = new google.maps.Map(document.getElementById("map"), options);

            //  latLng Array of JSON  [{lat,lng},{},...{}]
            let latLng = Array();
            //let places = Array();
            for (let i = 0; i < places.length; i++) {
                for (key in places[i]) {
                    if (key == "latLng") latLng.push(places[i][key]);
                }
            }


            // set markers on  Map
            for (let i = 0; i < latLng.length; i++) {
                setInfoMarker(places[i], new google.maps.Marker({
                    position: latLng[i],
                    map: map,
                    title: places[i].namePlace
                }));
            }
        }
    });

}