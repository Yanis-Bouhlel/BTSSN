<?php

/**
 * return l' objet personne demandé par $_GET['namePersonne'] depuis map.js
 */
$file =  "dataPersonnality.json";
$emailPersonne = isset($_GET['emailPersonne'])? $_GET['emailPersonne']: NULL;

 getPersonne( $file, $emailPersonne);




/**
 * @param $file_name fichier json de personnes
 * @param $name d'une personne
 * @return objet json de la personne à mapPersonnality dans map.js
 */
function getPersonne( $file_name, $email){

    
    $data = file_get_contents("dataPersonnality.json");
    $val = json_decode($data);
    echo json_encode($val);

}
?>